import json
import sys
import tempfile
import time
import unittest
from unittest.mock import patch
from argparse import Namespace
from datetime import date
from pathlib import Path

from openpyxl import Workbook

from app.services import finance
from app.services import finance_worker
from app.services.cabinets import Cabinet


def make_report(path: Path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Свод"
    ws.append(["ОПиУ маркетплейсов — свод"])
    ws.append(["Сен 2026 — Окт 2026. Кабинеты — Wildberries: К1."])
    ws.append([])
    ws.append(["Статья", "Итого", "% выручки", "Сен 2026", "Окт 2026", "Прогноз на 31.10"])
    ws.append(["ВЫРУЧКА"])
    ws.append(["Продажи (по цене продавца)", 1200, 1.2, 700, 500, 900])
    ws.append(["Wildberries", 1200, 1.2, 700, 500, 900])
    ws.append(["Выручка за вычетом возвратов", 1000, 1, 600, 400, 800])
    ws.append(["ИТОГО: РЕЗУЛЬТАТ ПО ДАННЫМ МАРКЕТПЛЕЙСОВ", 300, 0.3, 200, 100, 250])
    ws.append(["Налог с выручки, ₽", -40, -0.04, -24, -16, -30])
    ws.append(["Налог с выручки, % от выручки", -0.04, None, -0.04, -0.04, -0.04])
    ws.append(["ПРИБЫЛЬ (после себестоимости, подготовки и налога)", 100, 0.1, 80, 20, 60])
    ws.append(["ДОЛЯ ОТ ВЫРУЧКИ"])
    ws.append(["Результат", 0.3, None, 0.33, 0.25, 0.31])
    c = wb.create_sheet("Контроль")
    c.append(["Маркетплейс", "Кабинет", "Показатель", "Значение", "Статус"])
    c.append(["Wildberries", "К1", "Итог в сводном отчёте, ₽", 300, "OK"])
    c.append(["Ozon", "—", "Загрузка", "нет данных", "НЕТ ДАННЫХ"])
    g = wb.create_sheet("Товары")
    g.append(["Товары"])
    g.append(["Артикул", "Маркетплейс", "Штук", "Выручка"])
    g.append(["A", "Все маркетплейсы", 2, 1000])
    wb.save(path)


class FinanceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.dir = Path(self.temp.name)
        (self.dir / "opiu_all.py").write_text("print('ok')", encoding="utf-8")
        make_report(self.dir / "opiu_all_2026-09_2026-10.xlsx")

    def test_project_and_latest_report(self):
        self.assertEqual(finance.find_project_dir(str(self.dir)), self.dir.resolve())
        self.assertIsNone(finance.find_project_dir(str(self.dir / "missing")))
        # По умолчанию — папка opiu внутри WB OPS, без ссылок на внешние проекты
        self.assertEqual(finance.DEFAULT_DIR_CANDIDATES, (finance.ENGINE_DIR,))
        self.assertEqual(finance.ENGINE_DIR.name, "opiu")
        (self.dir / "~$opiu_all_lock.xlsx").write_bytes(b"")
        self.assertEqual(finance.latest_report(self.dir).name, "opiu_all_2026-09_2026-10.xlsx")

    def test_parse_summary_control_goods(self):
        data = finance.read_report(self.dir / "opiu_all_2026-09_2026-10.xlsx")
        s = data["summary"]
        self.assertEqual(s["periods"], ["Сен 2026", "Окт 2026"])
        self.assertEqual(s["forecast_title"], "Прогноз на 31.10")
        kinds = {r["label"]: r["kind"] for r in s["rows"] if r["kind"] != "detail"}
        self.assertEqual(kinds["Продажи (по цене продавца)"], "article")
        self.assertEqual(kinds["Выручка за вычетом возвратов"], "total")
        self.assertEqual(kinds["Налог с выручки, % от выручки"], "share")
        self.assertEqual(kinds["Результат"], "share")
        detail = next(r for r in s["rows"] if r["kind"] == "detail")
        self.assertEqual((detail["label"], detail["parent"], detail["forecast"]), ("Wildberries", "Продажи (по цене продавца)", 900))
        self.assertEqual(s["kpi"]["profit"]["total"], 100)
        self.assertEqual(s["kpi"]["tax"]["last"], -16)
        self.assertAlmostEqual(s["kpi"]["margin"]["total"], 0.1)
        self.assertEqual([r["problem"] for r in data["control"]], [False, True])
        self.assertEqual(data["goods"]["header"], ["Артикул", "Маркетплейс", "Штук", "Выручка"])
        self.assertEqual(data["goods"]["rows"], [["A", "Все маркетплейсы", 2, 1000]])
        self.assertEqual(finance.report_view(data)["detail"], {})

    def test_report_detail_uses_source_dates_and_cabinet_scope(self):
        from opiu import opiu_all

        months = ["2026-09", "2026-10"]
        days = ["2026-09-30", "2026-10-01", "2026-10-02", "2026-10-03"]
        source = {"marketplace": "Wildberries", "months": days, "cabinets": {
            "К1": {"rows": [["Выручка", "Продано", {days[0]: 100, days[1]: 300}]],
                   "sales": [[days[0], "A", 1, 100], [days[1], "A", 2, 300]],
                   "tax_base": {days[0]: 90, days[1]: 270}},
            "К2": {"rows": [["Выручка", "Продано", {days[2]: 200}]], "tax_base": {days[2]: 150}},
        }}
        entities, _ = opiu_all.build([source])
        book = Workbook()
        book.active.title = "Свод"
        opiu_all.write_pnl(book.active, {opiu_all.REV_SALES: {"Продано": dict(zip(months, (100, 500)))}},
                           months, "ОПиУ маркетплейсов — свод")
        for cabinet in source["cabinets"]:
            opiu_all.write_pnl(book.create_sheet(cabinet), {}, months, f"ОПиУ Wildberries — {cabinet}")
        opiu_all.write_report_detail(book, {name.lower() for name in book.sheetnames}, months, entities, [source],
                                     {"A": [("", 1, 10), ("2026-10-01", 1, 20)]}, {},
                                     {("Wildberries", None): 10}, {}, {}, None, date(2026, 11, 1))
        path = self.dir / "detailed.xlsx"
        opiu_all.save_workbook(book, path)

        data = finance.read_report(path)
        all_cabinets = finance.report_view(data)
        self.assertEqual(all_cabinets["summary"]["kpi"]["revenue"]["total"], 600)
        self.assertEqual(all_cabinets["detail"]["day"]["period_keys"], days[:3])
        self.assertEqual(all_cabinets["detail"]["week"]["period_keys"], ["2026-09-28"])
        self.assertEqual(all_cabinets["detail"]["week"]["kpi"]["revenue"]["total"], 600)
        for grain in ("day", "week"):
            variant = finance.report_view(data, "Wildberries|К1")["detail"][grain]
            self.assertEqual(variant["kpi"]["revenue"]["total"], 400)
            self.assertEqual(variant["kpi"]["cogs"]["total"], -50)
            self.assertEqual(variant["kpi"]["tax"]["total"], -36)
            self.assertEqual(variant["kpi"]["margin"]["total"], (400 - 50 - 36) / 400)

    def test_report_quality_marks_missing_cost_and_api_warning(self):
        data = finance.read_report(self.dir / "opiu_all_2026-09_2026-10.xlsx")
        view = finance.report_view(data)
        self.assertFalse(view["quality"]["reliable"])
        self.assertTrue(any("Себестоимость" in reason for reason in view["quality"]["reasons"]))

    def test_goods_streams_and_bounds_each_marketplace_preview(self):
        class Goods:
            def iter_rows(self, **_):
                yield ("Артикул", "Маркетплейс", "Штук")
                for mp in ("Все маркетплейсы", "Wildberries", "Ozon", "Яндекс Маркет"):
                    for i in range(500):
                        yield (f"{mp}-{i}", mp, 1)

        goods = finance.parse_goods(Goods(), finance.GOODS_LIMIT, by_marketplace=True)
        self.assertEqual(len(goods["rows"]), finance.GOODS_LIMIT * 4)
        for mp in finance.MARKETPLACE_NAMES:
            self.assertEqual(sum(row[1] == mp for row in goods["rows"]), finance.GOODS_LIMIT)

    def test_goods_limit_stops_consuming_the_sheet(self):
        class Goods:
            def iter_rows(self, **_):
                yield ("Артикул", "Штук")
                for i in range(200):
                    yield (str(i), 1)
                raise AssertionError("The preview must not read the rest of the sheet")

        self.assertEqual(len(finance.parse_goods(Goods(), 200)["rows"]), 200)

    def test_report_preview_keeps_later_marketplace_rows_with_bounded_memory(self):
        path = self.dir / "opiu_all_large.xlsx"
        make_report(path)
        from openpyxl import load_workbook
        book = load_workbook(path)
        goods = book["Товары"]
        goods.delete_rows(3, goods.max_row)
        for mp in ("Все маркетплейсы", "Wildberries", "Ozon", "Яндекс Маркет"):
            for i in range(250):
                goods.append([f"{mp}-{i}", mp, 1, 10])
        book.save(path)
        book.close()
        data = finance.read_report(path)
        self.assertEqual(len(data["goods"]["rows"]), finance.GOODS_LIMIT * 4)
        data["views"]["Ozon"] = data["summary"]
        rows = finance.report_view(data, "Ozon")["goods"]["rows"]
        self.assertEqual(len(rows), finance.GOODS_LIMIT)
        self.assertTrue(all(row[1] == "Ozon" for row in rows))

    def test_runner_persists_and_restores_status(self):
        path = self.dir / "finance_status.json"
        runner = finance.ReportRunner(path)
        runner.state.update(status="done", code=0, cabinets={"К1": {"status": "cache", "rows": 12}})
        runner.log.append("К1: из кэша")
        runner._persist()
        restored = finance.ReportRunner(path)
        self.assertEqual(restored.status()["status"], "done")
        self.assertEqual(restored.status()["cabinets"]["К1"]["rows"], 12)

    def test_workers_share_progress_and_reject_a_second_build(self):
        path = self.dir / "finance_status.json"
        owner = finance.ReportRunner(path)
        observer = finance.ReportRunner(path)
        (self.dir / "opiu_all.py").write_text(
            "from pathlib import Path\n"
            "import time\n"
            "print('[К1] загружено 12 строк', flush=True)\n"
            f"while not Path({str(self.dir / 'finish')!r}).exists(): time.sleep(0.01)\n",
            encoding="utf-8",
        )
        owner.start(self.dir, sys.executable, "cache")
        self.addCleanup(owner.stop)
        try:
            for _ in range(200):
                progress = observer.status()
                if progress["cabinets"].get("К1"):
                    break
                time.sleep(0.01)
            self.assertEqual(progress["status"], "running")
            self.assertEqual(progress["cabinets"]["К1"]["rows"], 12)
            with self.assertRaisesRegex(finance.FinanceError, "уже собирается"):
                observer.start(self.dir, sys.executable, "cache")
            observer.stop()
            self.assertIsNone(owner.process.poll())
            self.assertEqual(finance.ReportRunner(path).status()["status"], "running")
        finally:
            (self.dir / "finish").touch()
            owner.process.wait(timeout=5)
        for _ in range(200):
            if observer.status()["status"] == "done":
                break
            time.sleep(0.01)
        self.assertEqual(observer.status()["status"], "done")

    def test_worker_recovers_an_abandoned_build(self):
        path = self.dir / "finance_status.json"
        previous = finance.ReportRunner(path)
        previous.state.update(status="running", cabinets={"К1": {"status": "loading"}})
        previous._persist()
        recovered = finance.ReportRunner(path).status()
        self.assertEqual((recovered["status"], recovered["code"]), ("interrupted", -15))
        self.assertEqual(recovered["cabinets"]["К1"]["status"], "interrupted")

    def wait_runner(self, runner):
        for _ in range(200):
            state = runner.status()
            if state["status"] != "running":
                return state
            time.sleep(0.05)
        self.fail("finance process did not finish")

    def test_low_memory_refuses_start_and_preserves_data(self):
        report = finance.latest_report(self.dir)
        before = report.read_bytes()
        runner = finance.ReportRunner(self.dir / "status.json")
        with patch.object(finance_worker, "available_memory_mb", return_value=300):
            with self.assertRaisesRegex(finance.FinanceError, "мало свободной памяти"):
                runner.start(self.dir, sys.executable, "full")
        self.assertIsNone(runner.process)
        self.assertEqual(report.read_bytes(), before)
        handle = runner.try_run_lock()
        self.assertIsNotNone(handle)
        handle.close()

    def test_low_disk_refuses_start(self):
        runner = finance.ReportRunner(self.dir / "status.json")
        with patch.object(finance_worker.shutil, "disk_usage", return_value=Namespace(free=1)):
            with self.assertRaisesRegex(finance.FinanceError, "недостаточно места"):
                runner.start(self.dir, sys.executable, "full")

    def test_failed_staged_update_keeps_previous_cache_and_report(self):
        cache = self.dir / "Wildberries" / "cache"
        cache.mkdir(parents=True)
        original = cache / "data.json"
        original.write_text('{"old": 1}', encoding="utf-8")
        report = finance.latest_report(self.dir)
        before = report.read_bytes()
        (self.dir / "opiu_all.py").write_text(
            "from pathlib import Path\n"
            "Path('Wildberries/cache/data.json').write_text('broken')\n"
            f"Path({report.name!r}).write_text('broken')\n"
            "raise SystemExit(1)\n", encoding="utf-8")
        runner = finance.ReportRunner(self.dir / "status.json")
        runner.start(self.dir, sys.executable, "full")
        state = self.wait_runner(runner)
        self.assertEqual(state["status"], "error")
        self.assertIn("Предыдущие данные сохранены", state["message"])
        self.assertEqual(original.read_text(), '{"old": 1}')
        self.assertEqual(report.read_bytes(), before)

    def test_successful_update_publishes_cache_and_report_only(self):
        (self.dir / "opiu_all.py").write_text(
            "from pathlib import Path\n"
            "Path('Ozon/cache').mkdir(parents=True)\n"
            "Path('Ozon/cache/new.json').write_text('{}')\n"
            "Path('opiu_all_new.xlsx').write_bytes(b'new report')\n"
            "Path('settings.json').write_text('must not be published')\n", encoding="utf-8")
        runner = finance.ReportRunner(self.dir / "status.json")
        runner.start(self.dir, sys.executable, "full")
        self.assertEqual(self.wait_runner(runner)["status"], "done")
        self.assertEqual((self.dir / "Ozon/cache/new.json").read_text(), "{}")
        self.assertEqual((self.dir / "opiu_all_new.xlsx").read_bytes(), b"new report")
        self.assertFalse((self.dir / "settings.json").exists())

    def test_timeout_terminates_job_and_keeps_previous_cache(self):
        (self.dir / "opiu_all.py").write_text("import time\ntime.sleep(30)\n", encoding="utf-8")
        runner = finance.ReportRunner(self.dir / "status.json")
        with patch.dict("os.environ", {"WBOPS_FINANCE_TIMEOUT_SECONDS": "1"}):
            runner.start(self.dir, sys.executable, "full")
        state = self.wait_runner(runner)
        self.assertEqual(state["status"], "error")
        self.assertIn("лимит времени", state["message"])
        self.assertIsNotNone(runner.process.poll())

    def test_marketplace_memory_error_cannot_publish_partial_success(self):
        (self.dir / "opiu_all.py").write_text(
            "from pathlib import Path\n"
            "print('MemoryError in marketplace process', flush=True)\n"
            "Path('opiu_all_partial.xlsx').write_bytes(b'partial')\n", encoding="utf-8")
        runner = finance.ReportRunner(self.dir / "status.json")
        runner.start(self.dir, sys.executable, "full")
        state = self.wait_runner(runner)
        self.assertEqual(state["status"], "error")
        self.assertFalse((self.dir / "opiu_all_partial.xlsx").exists())

    def test_publication_failure_rolls_back_previous_artifacts(self):
        stage = self.dir / "staged"
        stage.mkdir()
        target = self.dir / "opiu_all_old.xlsx"
        target.write_bytes(b"old")
        (stage / target.name).write_bytes(b"new")
        (stage / "opiu_all_second.xlsx").write_bytes(b"second")
        original_replace = finance_worker.os.replace

        def failing_replace(source, destination):
            if Path(destination).name == "opiu_all_second.xlsx":
                raise OSError("simulated disk error")
            return original_replace(source, destination)

        with patch.object(finance_worker.os, "replace", side_effect=failing_replace):
            with self.assertRaisesRegex(OSError, "simulated disk error"):
                finance_worker.publish(stage, self.dir)
        self.assertEqual(target.read_bytes(), b"old")
        self.assertFalse((self.dir / "opiu_all_second.xlsx").exists())
        self.assertFalse(list(self.dir.glob("*.wbops-new")))

    def test_linux_limits_and_idle_io_priority(self):
        fake_resource = Namespace(RLIMIT_AS=1, RLIMIT_CPU=2, setrlimit=unittest.mock.Mock())
        with patch.object(finance_worker.os, "name", "posix"), \
                patch.object(finance_worker.os, "nice", create=True) as nice, \
                patch.object(finance_worker.shutil, "which", return_value="/usr/bin/ionice"), \
                patch.object(finance_worker.subprocess, "run") as run, \
                patch.dict(sys.modules, {"resource": fake_resource}):
            limits = finance_worker.Limits()
            finance_worker.lower_priority(limits)
            finance_worker.apply_limits(512, 600)
        nice.assert_called_once_with(10)
        self.assertEqual(run.call_args.args[0][:3], ["/usr/bin/ionice", "-c", "3"])
        self.assertEqual(fake_resource.setrlimit.call_args_list, [
            unittest.mock.call(1, (512 * finance_worker.MIB,) * 2),
            unittest.mock.call(2, (600, 601))])

    def test_linux_stop_also_kills_remaining_grandchildren(self):
        process = Namespace(pid=123, wait=unittest.mock.Mock(return_value=0))
        with patch.object(finance_worker.os, "name", "posix"), \
                patch.object(finance_worker.os, "killpg", create=True) as kill, \
                patch.object(finance_worker.signal, "SIGKILL", 9, create=True):
            finance_worker.stop_tree(process)
        self.assertEqual(kill.call_args_list, [
            unittest.mock.call(123, finance_worker.signal.SIGTERM),
            unittest.mock.call(123, 9)])


class SyncAccountsTests(unittest.TestCase):
    """Ключи API для ОПиУ берутся из кабинетов панели."""

    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.dir = Path(temp.name)

    def read(self, rel):
        return json.loads((self.dir / rel).read_text(encoding="utf-8-sig"))

    def test_creates_configs_from_cabinets(self):
        cabinets = [Cabinet("main", "Основной", "wb-token", tax_percent=6.0),
                    Cabinet("oz", "Озон", "oz-key", marketplace="ozon", client_id="123"),
                    Cabinet("ym", "Маркет", "ym-key", marketplace="yandex", client_id="777"),
                    Cabinet("empty", "Без ключа", "", marketplace="ozon")]
        self.assertEqual(finance.sync_accounts(self.dir, cabinets), {"wildberries": 1, "ozon": 1, "yandex": 1})
        wb = self.read("Wildberries/wb_accounts.json")
        self.assertEqual(wb["period"], {"from": finance.DEFAULT_PERIOD_FROM})
        self.assertEqual(wb["accounts"], [{"name": "Основной", "token": "wb-token", "enabled": True, "tax_percent": 6}])
        self.assertEqual(self.read("Ozon/ozon_accounts.json")["accounts"],
                         [{"name": "Озон", "client_id": "123", "api_key": "oz-key", "enabled": True}])
        self.assertEqual(self.read("YandexMarket/ym_accounts.json")["accounts"],
                         [{"name": "Маркет", "api_key": "ym-key", "enabled": True, "business_id": 777}])

    def test_updates_existing_config_keeping_name_and_fields(self):
        path = self.dir / "Wildberries" / "wb_accounts.json"
        path.parent.mkdir()
        path.write_text(json.dumps({"period": {"from": "2025-09"}, "tax_percent": 1, "accounts": [
            {"name": "ИП Петров", "token": "old", "enabled": True, "extra": 1},
            {"name": "Старый кабинет", "token": "x", "enabled": True}]}, ensure_ascii=False), encoding="utf-8")
        cabinets = [Cabinet("main", "Петров", "new-token"), Cabinet("off", "Второй", "t2", enabled=False)]
        finance.sync_accounts(self.dir, cabinets)
        cfg = self.read("Wildberries/wb_accounts.json")
        self.assertEqual((cfg["period"], cfg["tax_percent"]), ({"from": "2025-09"}, 1))
        self.assertEqual(cfg["accounts"], [
            {"name": "ИП Петров", "token": "new-token", "enabled": True, "extra": 1},   # имя — ключ кэша
            {"name": "Старый кабинет", "token": "x", "enabled": False},                # нет в панели
            {"name": "Второй", "token": "t2", "enabled": False}])
        self.assertTrue((path.parent / "wb_accounts.json.bak").exists())
        self.assertFalse((self.dir / "Ozon").exists())   # площадку без кабинетов в панели не трогаем
        mtime = path.stat().st_mtime_ns
        (path.parent / "wb_accounts.json.bak").unlink()
        finance.sync_accounts(self.dir, cabinets)
        self.assertEqual(path.stat().st_mtime_ns, mtime)   # без изменений файл не переписывается
        self.assertFalse((path.parent / "wb_accounts.json.bak").exists())

    def test_runner_cache_mode_fills_missing(self):
        runner = finance.ReportRunner(self.dir / "finance_status.json")
        (self.dir / "opiu_all.py").write_text("import sys; print(' '.join(sys.argv[1:]))", encoding="utf-8")
        runner.start(self.dir, sys.executable, "cache", note="Ключи API из кабинетов панели: WB — 1")
        runner.process.wait()
        for _ in range(100):
            if runner.status()["status"] != "running":
                break
            time.sleep(0.05)
        self.assertEqual(runner.status()["log"], ["Ключи API из кабинетов панели: WB — 1",
                                                  "--no-unit --from-cache --fill-missing"])


class FillMissingTests(unittest.TestCase):
    """«Собрать из кэша»: кабинеты, которых нет в кэше, загружаются из API."""

    def setUp(self):
        sys.path.insert(0, str(finance.ENGINE_DIR))
        self.addCleanup(sys.path.remove, str(finance.ENGINE_DIR))
        import opiu_all
        self.opiu = opiu_all
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.dir = Path(temp.name)
        (self.dir / "WB").mkdir()
        (self.dir / "WB" / "wb.py").write_text("", encoding="utf-8")
        (self.dir / "WB" / "wb.json").write_text(json.dumps({"period": {"from": "2026-01"}, "accounts": [
            {"name": "A", "token": "a"}, {"name": "B", "token": "b"}, {"name": "C", "token": "c", "enabled": False}]}),
            encoding="utf-8")
        self.mp = {"key": "wb", "name": "Wildberries", "script": "WB/wb.py", "config": "WB/wb.json"}
        old_here, old_run = opiu_all.HERE, opiu_all.run_script
        opiu_all.HERE = self.dir
        self.addCleanup(setattr, opiu_all, "HERE", old_here)
        self.addCleanup(setattr, opiu_all, "run_script", old_run)
        self.calls = []

        def fake_run(mp, dump, from_cache, grain="month", config=None):
            names = [a["name"] for a in json.loads(Path(config).read_text(encoding="utf-8"))["accounts"]] if config else None
            self.calls.append((from_cache, names))
            if from_cache:
                return {"months": ["2026-09"], "cabinets": {"A": {"checks": []}}}, 1, ["[B] ОШИБКА: B: нет кэша"]
            return {"months": ["2026-10"], "cabinets": {n: {"checks": []} for n in names}}, 0, []
        opiu_all.run_script = fake_run

    def args(self, **kw):
        return Namespace(**{"from_cache": True, "fill_missing": False, "cache_for": None,
                            "grain": "month", "cabinet": None, **kw})

    def test_loads_only_missing_cabinets_from_api(self):
        data, note, errors = self.opiu.run_marketplace(self.mp, self.args(fill_missing=True), str(self.dir))
        self.assertEqual(self.calls, [(True, None), (False, ["B"])])
        self.assertEqual(sorted(data["cabinets"]), ["A", "B"])
        self.assertEqual(data["months"], ["2026-09", "2026-10"])
        self.assertEqual(data["cabinets"]["B"]["checks"][0], ["Данные из API: кабинета не было в кэше", "да"])
        self.assertEqual(note, "не было в кэше, загружено из API: B")
        self.assertEqual(errors, [])

    def test_plain_from_cache_does_not_call_api(self):
        data, note, _ = self.opiu.run_marketplace(self.mp, self.args(), str(self.dir))
        self.assertEqual(self.calls, [(True, None)])
        self.assertEqual(sorted(data["cabinets"]), ["A"])
        self.assertIn("нет в отчёте кабинетов: B", note)


if __name__ == "__main__":
    unittest.main()
